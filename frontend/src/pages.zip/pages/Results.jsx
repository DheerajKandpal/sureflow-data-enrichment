import { useState, useEffect } from 'react'
import axios from 'axios'

const API     = 'http://localhost:8000'
const PAGE_SIZE = 50

export default function Results() {
  const [data, setData]     = useState(null)
  const [page, setPage]     = useState(0)
  const [error, setError]   = useState(null)
  const [jobId, setJobId]   = useState(null)
  const [job, setJob]       = useState(null)

  useEffect(() => {
    const id = localStorage.getItem('current_job_id_results') || localStorage.getItem('current_job_id')
    if (!id) return
    setJobId(id)

    axios.get(`${API}/api/jobs/${id}`)
      .then(r => setJob(r.data))
      .catch(() => {})

    axios.get(`${API}/api/results/${id}`)
      .then(r => setData(r.data))
      .catch(e => setError(e.response?.data?.detail || 'Failed to load results'))
  }, [])

  if (!jobId) return (
    <div className="p-8 text-center text-slate-400">No results to show. Run a batch first.</div>
  )

  if (error) return (
    <div className="p-8">
      <div className="p-4 bg-red-900/30 border border-red-700 rounded-xl text-red-300 text-sm">{error}</div>
    </div>
  )

  if (!data) return (
    <div className="p-8 text-center text-slate-400">Loading results...</div>
  )

  const totalPages = Math.ceil(data.rows.length / PAGE_SIZE)
  const pageRows   = data.rows.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE)

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">Results</h1>
          <p className="text-slate-400 text-sm">{data.rows.length} rows — {data.columns.length} columns</p>
        </div>
        {job?.output_csv && (
          <button
            onClick={() => window.open(`${API}/api/download/${job.output_csv}`)}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg transition-colors text-sm"
          >
            ⬇ Download CSV
          </button>
        )}
      </div>

      {/* Table */}
      <div className="bg-slate-800 rounded-xl overflow-hidden border border-slate-700">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700">
                {data.columns.map(col => (
                  <th key={col} className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide whitespace-nowrap">
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((row, i) => (
                <tr key={i} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                  {data.columns.map(col => (
                    <td key={col} className="px-4 py-2.5 text-slate-300 whitespace-nowrap max-w-xs truncate">
                      {row[col] || '—'}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <p className="text-slate-400 text-sm">
            Page {page + 1} of {totalPages} ({data.rows.length} total rows)
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage(p => Math.max(0, p - 1))}
              disabled={page === 0}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 disabled:opacity-40 rounded-lg text-sm text-white transition-colors"
            >← Prev</button>
            <button
              onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
              disabled={page === totalPages - 1}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 disabled:opacity-40 rounded-lg text-sm text-white transition-colors"
            >Next →</button>
          </div>
        </div>
      )}
    </div>
  )
}
