import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const API = 'http://localhost:8000'

export default function History() {
  const navigate   = useNavigate()
  const [jobs, setJobs] = useState([])

  useEffect(() => {
    axios.get(`${API}/api/jobs`)
      .then(r => setJobs(r.data))
      .catch(() => {})
  }, [])

  const viewResults = (jobId) => {
    localStorage.setItem('current_job_id_results', jobId)
    navigate('/results')
  }

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-white mb-1">History</h1>
      <p className="text-slate-400 text-sm mb-8">All past batch runs</p>

      {jobs.length === 0 ? (
        <div className="text-center py-16 text-slate-500">No batch history yet.</div>
      ) : (
        <div className="space-y-3">
          {jobs.map(job => (
            <div key={job.job_id} className="bg-slate-800 rounded-xl p-5 flex items-center justify-between border border-slate-700">
              <div className="flex items-center gap-4">
                <span className={`px-2.5 py-1 rounded-full text-xs font-semibold
                  ${job.status === 'done'    ? 'bg-green-800 text-green-300' :
                    job.status === 'failed'  ? 'bg-red-800 text-red-300' :
                    job.status === 'running' ? 'bg-indigo-800 text-indigo-300 animate-pulse' :
                    'bg-slate-700 text-slate-300'}`}>
                  {job.status}
                </span>
                <div>
                  <div className="text-white font-medium text-sm">{job.filename || 'Unknown file'}</div>
                  <div className="text-slate-400 text-xs mt-0.5">
                    {job.workflow} · {job.started_at} · {job.total} rows
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                {/* Mini stats */}
                <div className="flex gap-3 text-xs">
                  <span className="text-green-400">✅ {job.success}</span>
                  <span className="text-yellow-400">⚠️ {job.saved_422}</span>
                  <span className="text-red-400">❌ {job.failed}</span>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  {job.status === 'done' && (
                    <>
                      <button
                        onClick={() => viewResults(job.job_id)}
                        className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white text-xs rounded-lg transition-colors"
                      >
                        View
                      </button>
                      {job.output_csv && (
                        <button
                          onClick={() => window.open(`${API}/api/download/${job.output_csv}`)}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs rounded-lg transition-colors"
                        >
                          ⬇ CSV
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
