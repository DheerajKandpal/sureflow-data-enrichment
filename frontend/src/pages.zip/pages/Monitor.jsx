import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const API = 'http://localhost:8000'

export default function Monitor() {
  const navigate  = useNavigate()
  const logRef    = useRef()
  const [job, setJob]   = useState(null)
  const [logs, setLogs] = useState([])
  const [done, setDone] = useState(false)

  const jobId = localStorage.getItem('current_job_id')

  useEffect(() => {
    if (!jobId) return

    // Poll job status
    const pollInterval = setInterval(async () => {
      try {
        const res = await axios.get(`${API}/api/jobs/${jobId}`)
        setJob(res.data)
        if (res.data.status === 'done' || res.data.status === 'failed') {
          setDone(true)
          clearInterval(pollInterval)
        }
      } catch (e) {}
    }, 1000)

    // WebSocket for live logs
    const ws = new WebSocket(`ws://localhost:8000/ws/jobs/${jobId}`)
    ws.onmessage = (e) => {
      if (e.data === '__DONE__') {
        setDone(true)
        ws.close()
        return
      }
      setLogs(prev => [...prev, e.data])
      // Auto-scroll log
      setTimeout(() => {
        if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
      }, 50)
    }

    return () => {
      clearInterval(pollInterval)
      ws.close()
    }
  }, [jobId])

  if (!jobId) {
    return (
      <div className="p-8 text-center">
        <p className="text-slate-400">No active job. Go to Upload to start one.</p>
        <button onClick={() => navigate('/')} className="mt-4 px-4 py-2 bg-indigo-600 rounded-lg text-white text-sm">Go to Upload</button>
      </div>
    )
  }

  const progress = job ? Math.round((job.progress / Math.max(job.total, 1)) * 100) : 0

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-white mb-1">Live Monitor</h1>
      <p className="text-slate-400 text-sm mb-8">Watching job {jobId?.slice(0, 8)}...</p>

      {job && (
        <div className="space-y-6">

          {/* Status badge */}
          <div className="flex items-center gap-3">
            <span className={`px-3 py-1 rounded-full text-xs font-semibold
              ${job.status === 'done'    ? 'bg-green-800 text-green-300' :
                job.status === 'failed'  ? 'bg-red-800 text-red-300' :
                job.status === 'running' ? 'bg-indigo-800 text-indigo-300' :
                'bg-slate-700 text-slate-300'}`}>
              {job.status.toUpperCase()}
            </span>
            <span className="text-slate-400 text-sm">{job.workflow} — {job.filename}</span>
          </div>

          {/* Progress bar */}
          <div className="bg-slate-800 rounded-xl p-5">
            <div className="flex justify-between text-sm text-slate-400 mb-2">
              <span>Progress</span>
              <span>{job.progress} / {job.total} rows ({progress}%)</span>
            </div>
            <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-500 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Counters */}
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Success',   value: job.success,      color: 'text-green-400',  bg: 'bg-green-900/20' },
              { label: 'Saved 422', value: job.saved_422,    color: 'text-yellow-400', bg: 'bg-yellow-900/20' },
              { label: 'Failed',    value: job.failed,       color: 'text-red-400',    bg: 'bg-red-900/20' },
              { label: 'Skipped',   value: job.skipped + job.already_exists, color: 'text-slate-400', bg: 'bg-slate-700' },
            ].map(c => (
              <div key={c.label} className={`${c.bg} rounded-xl p-4 text-center`}>
                <div className={`text-2xl font-bold ${c.color}`}>{c.value}</div>
                <div className="text-xs text-slate-400 mt-1">{c.label}</div>
              </div>
            ))}
          </div>

          {/* Live log */}
          <div className="bg-slate-800 rounded-xl p-4">
            <div className="text-xs text-slate-400 mb-3 font-semibold uppercase tracking-wide">Live Log</div>
            <div ref={logRef} className="h-64 overflow-y-auto font-mono text-xs text-slate-300 space-y-1">
              {logs.length === 0 ? (
                <p className="text-slate-500">Waiting for logs...</p>
              ) : (
                logs.map((l, i) => (
                  <div key={i} className={
                    l.includes('✅') ? 'text-green-400' :
                    l.includes('⚠️') ? 'text-yellow-400' :
                    l.includes('❌') || l.includes('ERROR') ? 'text-red-400' :
                    l.includes('⏭️') ? 'text-slate-500' :
                    'text-slate-300'
                  }>{l}</div>
                ))
              )}
            </div>
          </div>

          {/* Done actions */}
          {done && job.status === 'done' && (
            <div className="flex gap-3">
              <button
                onClick={() => {
                  localStorage.setItem('current_job_id_results', jobId)
                  navigate('/results')
                }}
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition-colors"
              >
                View Results →
              </button>
              <button
                onClick={() => window.open(`${API}/api/download/${job.output_csv}`)}
                className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded-xl transition-colors"
              >
                ⬇ Download CSV
              </button>
            </div>
          )}

          {done && job.status === 'failed' && (
            <div className="p-4 bg-red-900/30 border border-red-700 rounded-xl text-red-300 text-sm">
              ❌ Job failed: {job.error}
            </div>
          )}

        </div>
      )}
    </div>
  )
}
