import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const API = 'http://localhost:8000'

export default function Upload() {
  const navigate    = useNavigate()
  const fileRef     = useRef()
  const [file, setFile]         = useState(null)
  const [uploading, setUploading] = useState(false)
  const [uploadResult, setUploadResult] = useState(null)
  const [error, setError]       = useState(null)
  const [selectedWorkflow, setSelectedWorkflow] = useState('')
  const [columnMap, setColumnMap] = useState({})
  const [mode, setMode]         = useState('default') // default | force | rebuild_csv
  const [launching, setLaunching] = useState(false)

  const handleDrop = (e) => {
    e.preventDefault()
    const f = e.dataTransfer.files[0]
    if (f) handleFileSelect(f)
  }

  const handleFileSelect = async (f) => {
    setFile(f)
    setError(null)
    setUploadResult(null)
    setUploading(true)

    const form = new FormData()
    form.append('file', f)

    try {
      const res = await axios.post(`${API}/api/upload`, form)
      setUploadResult(res.data)

      // Auto-select first detected workflow
      const detected = res.data.detected
      const firstDetected = Object.values(detected)[0]
      if (firstDetected?.workflow) {
        setSelectedWorkflow(firstDetected.workflow)
      } else if (res.data.workflows.length > 0) {
        setSelectedWorkflow(res.data.workflows[0])
      }

      // Auto-fill column map from detection
      const map = {}
      Object.entries(detected).forEach(([idType, info]) => {
        map[idType] = info.column
      })
      setColumnMap(map)

    } catch (e) {
      setError(e.response?.data?.detail || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  const handleRun = async () => {
    if (!selectedWorkflow) return
    setLaunching(true)
    try {
      const res = await axios.post(`${API}/api/jobs/run`, {
        filename:    file.name,
        workflow:    selectedWorkflow,
        column_map:  columnMap,
        force:       mode === 'force',
        rebuild_csv: mode === 'rebuild_csv',
      })
      // Store job id and navigate to monitor
      localStorage.setItem('current_job_id', res.data.job_id)
      navigate('/monitor')
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to start job')
    } finally {
      setLaunching(false)
    }
  }

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-white mb-1">Upload Batch</h1>
      <p className="text-slate-400 text-sm mb-8">Upload an Excel or CSV file to start processing</p>

      {/* Drop zone */}
      <div
        onDrop={handleDrop}
        onDragOver={e => e.preventDefault()}
        onClick={() => fileRef.current.click()}
        className="border-2 border-dashed border-slate-600 hover:border-indigo-500 rounded-xl p-12 text-center cursor-pointer transition-colors duration-200 bg-slate-800"
      >
        <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden"
          onChange={e => handleFileSelect(e.target.files[0])} />
        <div className="text-4xl mb-3">📁</div>
        {uploading ? (
          <p className="text-indigo-400 font-medium">Uploading and detecting columns...</p>
        ) : file ? (
          <div>
            <p className="text-white font-medium">{file.name}</p>
            <p className="text-slate-400 text-sm mt-1">Click to change file</p>
          </div>
        ) : (
          <div>
            <p className="text-white font-medium">Drop your file here</p>
            <p className="text-slate-400 text-sm mt-1">or click to browse — .xlsx, .xls, .csv</p>
          </div>
        )}
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-900/40 border border-red-700 rounded-lg text-red-300 text-sm">{error}</div>
      )}

      {/* Detection results */}
      {uploadResult && (
        <div className="mt-6 space-y-6">

          {/* File info */}
          <div className="bg-slate-800 rounded-xl p-4 flex gap-6">
            <div><div className="text-xs text-slate-400 mb-1">File</div><div className="text-white font-medium">{uploadResult.filename}</div></div>
            <div><div className="text-xs text-slate-400 mb-1">Rows</div><div className="text-white font-medium">{uploadResult.rows}</div></div>
            <div><div className="text-xs text-slate-400 mb-1">Columns</div><div className="text-white font-medium">{uploadResult.columns.length}</div></div>
          </div>

          {/* Detected columns */}
          <div className="bg-slate-800 rounded-xl p-5">
            <h2 className="text-sm font-semibold text-slate-300 mb-4">Detected Identifier Columns</h2>
            {Object.keys(uploadResult.detected).length === 0 ? (
              <p className="text-slate-400 text-sm">No identifier columns detected automatically.</p>
            ) : (
              <div className="space-y-3">
                {Object.entries(uploadResult.detected).map(([idType, info]) => (
                  <div key={idType} className="flex items-center gap-3">
                    <span className="text-green-400 text-sm">✅</span>
                    <span className="text-slate-300 text-sm w-36">{idType}</span>
                    <select
                      value={columnMap[idType] || ''}
                      onChange={e => setColumnMap(prev => ({ ...prev, [idType]: e.target.value }))}
                      className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-1.5 focus:outline-none focus:border-indigo-500"
                    >
                      {uploadResult.columns.map(col => (
                        <option key={col} value={col}>{col}</option>
                      ))}
                    </select>
                    <span className="text-slate-400 text-xs">→ workflow: {info.workflow}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Workflow selector */}
          <div className="bg-slate-800 rounded-xl p-5">
            <h2 className="text-sm font-semibold text-slate-300 mb-4">Select Workflow</h2>
            <div className="flex flex-wrap gap-2">
              {uploadResult.workflows.map(wf => (
                <button
                  key={wf}
                  onClick={() => setSelectedWorkflow(wf)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
                    ${selectedWorkflow === wf
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}`}
                >
                  {wf}
                </button>
              ))}
            </div>
          </div>

          {/* Run mode */}
          <div className="bg-slate-800 rounded-xl p-5">
            <h2 className="text-sm font-semibold text-slate-300 mb-4">Run Mode</h2>
            <div className="flex gap-3">
              {[
                { key: 'default',     label: 'Default',      desc: 'Skip existing JSONs',        icon: '⚡' },
                { key: 'force',       label: 'Force',        desc: 'Re-hit API for all rows',     icon: '🔁' },
                { key: 'rebuild_csv', label: 'Rebuild CSV',  desc: 'No API calls, use existing',  icon: '📄' },
              ].map(m => (
                <button
                  key={m.key}
                  onClick={() => setMode(m.key)}
                  className={`flex-1 p-3 rounded-lg border text-left transition-colors
                    ${mode === m.key
                      ? 'border-indigo-500 bg-indigo-900/30'
                      : 'border-slate-600 bg-slate-700 hover:border-slate-500'}`}
                >
                  <div className="text-lg mb-1">{m.icon}</div>
                  <div className="text-white text-sm font-medium">{m.label}</div>
                  <div className="text-slate-400 text-xs mt-0.5">{m.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Run button */}
          <button
            onClick={handleRun}
            disabled={!selectedWorkflow || launching}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors"
          >
            {launching ? 'Starting...' : `▶ Run ${selectedWorkflow}`}
          </button>

        </div>
      )}
    </div>
  )
}
