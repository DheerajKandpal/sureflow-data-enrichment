import { useState, useEffect } from 'react'
import axios from 'axios'

const API = 'http://localhost:8000'

function Section({ title, children }) {
  return (
    <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
      <div className="px-5 py-3 border-b border-slate-700 bg-slate-750">
        <h2 className="text-sm font-semibold text-slate-200">{title}</h2>
      </div>
      <div className="p-5">{children}</div>
    </div>
  )
}

export default function Settings() {
  const [config, setConfig]   = useState(null)
  const [saved, setSaved]     = useState(false)
  const [error, setError]     = useState(null)

  // Token form
  const [tokenName, setTokenName]   = useState('')
  const [tokenValue, setTokenValue] = useState('')

  // API form
  const [apiForm, setApiForm] = useState({
    name: '', url: '', method: 'POST',
    payload_template: '{\n  "id_number": "{input}"\n}',
    success_codes: '200', save_codes: '200,422', retry_codes: '500,502,503',
  })

  // Workflow form
  const [wfForm, setWfForm] = useState({
    name: '', label: '', input_field: '', api: '', token: '',
  })

  useEffect(() => {
    axios.get(`${API}/api/config/full`)
      .then(r => setConfig(r.data))
      .catch(() => setError('Failed to load config'))
  }, [])

  const reload = () => axios.get(`${API}/api/config/full`).then(r => setConfig(r.data))

  const flash = () => { setSaved(true); setTimeout(() => setSaved(false), 2000) }

  // ── Tokens ─────────────────────────────────────────────────
  const addToken = async () => {
    if (!tokenName || !tokenValue) return
    await axios.post(`${API}/api/config/tokens`, { name: tokenName, value: tokenValue })
    setTokenName(''); setTokenValue('')
    reload(); flash()
  }

  const deleteToken = async (name) => {
    await axios.delete(`${API}/api/config/tokens/${name}`)
    reload()
  }

  // ── APIs ───────────────────────────────────────────────────
  const addApi = async () => {
    if (!apiForm.name || !apiForm.url) return
    try {
      const payload = JSON.parse(apiForm.payload_template)
      await axios.post(`${API}/api/config/apis`, {
        ...apiForm,
        payload_template: payload,
        success_codes: apiForm.success_codes.split(',').map(Number),
        save_codes:    apiForm.save_codes.split(',').map(Number),
        retry_codes:   apiForm.retry_codes.split(',').map(Number),
      })
      setApiForm({ name: '', url: '', method: 'POST',
        payload_template: '{\n  "id_number": "{input}"\n}',
        success_codes: '200', save_codes: '200,422', retry_codes: '500,502,503' })
      reload(); flash()
    } catch (e) {
      setError('Invalid JSON in payload template')
    }
  }

  const deleteApi = async (name) => {
    await axios.delete(`${API}/api/config/apis/${name}`)
    reload()
  }

  // ── Workflows ──────────────────────────────────────────────
  const addWorkflow = async () => {
    if (!wfForm.name || !wfForm.api || !wfForm.input_field) return
    await axios.post(`${API}/api/config/workflows`, wfForm)
    setWfForm({ name: '', label: '', input_field: '', api: '', token: '' })
    reload(); flash()
  }

  const deleteWorkflow = async (name) => {
    await axios.delete(`${API}/api/config/workflows/${name}`)
    reload()
  }

  if (!config) return <div className="p-8 text-slate-400">Loading config...</div>

  const tokens    = config.tokens    || {}
  const apis      = config.apis      || {}
  const workflows = config.workflows || {}

  return (
    <div className="p-8 max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">Settings</h1>
          <p className="text-slate-400 text-sm">Manage tokens, APIs, and workflows — all saved to config.yaml</p>
        </div>
        {saved && <span className="text-green-400 text-sm font-medium">✅ Saved</span>}
      </div>

      {error && (
        <div className="p-4 bg-red-900/30 border border-red-700 rounded-xl text-red-300 text-sm">
          {error}
          <button onClick={() => setError(null)} className="ml-3 underline">dismiss</button>
        </div>
      )}

      {/* ── Tokens ─────────────────────────────────────────── */}
      <Section title="🔑 API Tokens">
        <div className="space-y-2 mb-4">
          {Object.entries(tokens).map(([name, value]) => (
            <div key={name} className="flex items-center justify-between bg-slate-700 rounded-lg px-4 py-2.5">
              <div>
                <span className="text-white text-sm font-medium">{name}</span>
                <span className="text-slate-400 text-xs ml-3">{String(value).slice(0, 20)}...</span>
              </div>
              <button onClick={() => deleteToken(name)} className="text-red-400 hover:text-red-300 text-xs transition-colors">Delete</button>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            placeholder="Token name (e.g. primary)"
            value={tokenName}
            onChange={e => setTokenName(e.target.value)}
            className="flex-1 bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500"
          />
          <input
            placeholder="Token value (without Bearer)"
            value={tokenValue}
            onChange={e => setTokenValue(e.target.value)}
            className="flex-[2] bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500"
          />
          <button onClick={addToken} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm rounded-lg transition-colors">Add</button>
        </div>
      </Section>

      {/* ── APIs ───────────────────────────────────────────── */}
      <Section title="🔌 API Endpoints">
        <div className="space-y-2 mb-4">
          {Object.entries(apis).map(([name, api]) => (
            <div key={name} className="flex items-center justify-between bg-slate-700 rounded-lg px-4 py-2.5">
              <div>
                <span className="text-white text-sm font-medium">{name}</span>
                <span className="text-slate-400 text-xs ml-3">{api.method} {api.url}</span>
              </div>
              <button onClick={() => deleteApi(name)} className="text-red-400 hover:text-red-300 text-xs transition-colors">Delete</button>
            </div>
          ))}
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <input placeholder="API name (e.g. rc_details)"
              value={apiForm.name} onChange={e => setApiForm(p => ({...p, name: e.target.value}))}
              className="col-span-2 bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500" />
            <select value={apiForm.method} onChange={e => setApiForm(p => ({...p, method: e.target.value}))}
              className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">
              <option>POST</option><option>GET</option>
            </select>
          </div>
          <input placeholder="URL (e.g. https://kyc-api.surepass.io/api/v1/rc/rc-full)"
            value={apiForm.url} onChange={e => setApiForm(p => ({...p, url: e.target.value}))}
            className="w-full bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500" />
          <div>
            <label className="text-xs text-slate-400 mb-1 block">Payload Template (JSON) — use {'{input}'} for the identifier</label>
            <textarea
              value={apiForm.payload_template}
              onChange={e => setApiForm(p => ({...p, payload_template: e.target.value}))}
              rows={4}
              className="w-full bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 font-mono focus:outline-none focus:border-indigo-500"
            />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Success codes</label>
              <input value={apiForm.success_codes} onChange={e => setApiForm(p => ({...p, success_codes: e.target.value}))}
                className="w-full bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500" />
            </div>
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Save codes</label>
              <input value={apiForm.save_codes} onChange={e => setApiForm(p => ({...p, save_codes: e.target.value}))}
                className="w-full bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500" />
            </div>
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Retry codes</label>
              <input value={apiForm.retry_codes} onChange={e => setApiForm(p => ({...p, retry_codes: e.target.value}))}
                className="w-full bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500" />
            </div>
          </div>
          <button onClick={addApi} className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition-colors">
            Add API Endpoint
          </button>
        </div>
      </Section>

      {/* ── Workflows ──────────────────────────────────────── */}
      <Section title="⚡ Workflows">
        <div className="space-y-2 mb-4">
          {Object.entries(workflows).map(([name, wf]) => (
            <div key={name} className="flex items-center justify-between bg-slate-700 rounded-lg px-4 py-2.5">
              <div>
                <span className="text-white text-sm font-medium">{name}</span>
                <span className="text-slate-400 text-xs ml-3">{wf.label} · input: {wf.input_field} · api: {wf.api}</span>
              </div>
              <button onClick={() => deleteWorkflow(name)} className="text-red-400 hover:text-red-300 text-xs transition-colors">Delete</button>
            </div>
          ))}
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <input placeholder="Workflow name (e.g. rc_details)"
              value={wfForm.name} onChange={e => setWfForm(p => ({...p, name: e.target.value}))}
              className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500" />
            <input placeholder="Label (e.g. RC Number → RC Details)"
              value={wfForm.label} onChange={e => setWfForm(p => ({...p, label: e.target.value}))}
              className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500" />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <input placeholder="Input field (e.g. rc_number)"
              value={wfForm.input_field} onChange={e => setWfForm(p => ({...p, input_field: e.target.value}))}
              className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500" />
            <select value={wfForm.api} onChange={e => setWfForm(p => ({...p, api: e.target.value}))}
              className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">
              <option value="">Select API</option>
              {Object.keys(apis).map(a => <option key={a} value={a}>{a}</option>)}
            </select>
            <select value={wfForm.token} onChange={e => setWfForm(p => ({...p, token: e.target.value}))}
              className="bg-slate-700 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">
              <option value="">Select Token</option>
              {Object.keys(tokens).map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <button onClick={addWorkflow} className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition-colors">
            Add Workflow
          </button>
        </div>
      </Section>
    </div>
  )
}
